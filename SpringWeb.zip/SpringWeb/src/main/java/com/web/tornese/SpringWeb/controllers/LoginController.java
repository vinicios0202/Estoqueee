package com.web.tornese.SpringWeb.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.web.tornese.SpringWeb.models.Cadastro;
import com.web.tornese.SpringWeb.repositorio.CadastrosRepo;

@Controller
public class LoginController{
  @Autowired
  private CadastrosRepo repo;
    
  @GetMapping("/login")
  public String index(){
    return "login/index";
    }

  @PostMapping("/logar")
  public String logar(Model model, Cadastro cadParam){
    Cadastro cad = this.repo.Login(cadParam.getEmail(), cadParam.getSenha());
    if(cad != null){
      return "redirect:/administradores";
        }
    model.addAttribute("erro", "Usuário ou senha inválidos");
    return "login/index";


}}

   

