package com.web.tornese.SpringWeb.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.web.tornese.SpringWeb.models.Cadastro;
import com.web.tornese.SpringWeb.repositorio.CadastrosRepo;

@Controller
public class CadastrosController {


  @Autowired
  private CadastrosRepo repo;

  @GetMapping("/cadastros")
  public String index(Model model){
    List<Cadastro> cadastros = (List<Cadastro>)repo.findAll();
    model.addAttribute("cadastros", cadastros);
    return "cadastros/index";
  }

  @GetMapping("/conta")
  public String conta(Model model){
    List<Cadastro> cadastros = (List<Cadastro>)repo.findAll();
    model.addAttribute("cadastros", cadastros);
    return "cadastros/conta";
  }

  @PostMapping("/cadastros/criar")
  public String criar(Cadastro cadastro){
    repo.save(cadastro);
    return "redirect:/login";
    
  }
}
