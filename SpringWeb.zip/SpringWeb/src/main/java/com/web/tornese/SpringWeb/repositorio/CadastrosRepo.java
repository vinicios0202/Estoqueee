package com.web.tornese.SpringWeb.repositorio;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.web.tornese.SpringWeb.models.Cadastro;

public interface CadastrosRepo extends CrudRepository<Cadastro, Integer>{

@Query(value="select CASE WHEN count(1) > 0 THEN 'true' ELSE 'false' END  from cadastros where id = :id", nativeQuery = true)
  public boolean exist(int id);

@Query(value="select * from cadastros where email = :email and senha = :senha", nativeQuery = true)
  public Cadastro Login(String email, String senha);
    
}
